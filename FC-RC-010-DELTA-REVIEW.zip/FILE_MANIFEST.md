# FILE_MANIFEST — FC-RC-010-DELTA-REVIEW.zip

**Package:** FC-RC-010 — Final Correction Review Package (evidence packaging only)
**Covers:** FC-RC-FIX-009 — correction of review defects RC-001…RC-004
**Repository:** Vocabulary Flashcards, branch `newfeature`, HEAD `8d76720ab0cc21771602574a9aa161d5dcbd9e15`
**Working-tree state at packaging:** 24 tracked files modified, 13 untracked entries (before this ZIP itself), zero commits
**Date:** 2026-10-16
**Packaging method:** whitelist copy (byte-identical) of the files listed below, plus git-generated patch, plus this
manifest and `VERIFICATION.md`. Nothing else was read into the package; no application code, migration, test or
configuration file was modified by this packaging task.

---

## 1. Package contents (19 files, paths mirror the repository)

| # | Path in ZIP | Category |
|---|---|---|
| 1 | `FILE_MANIFEST.md` | package metadata (this file) |
| 2 | `VERIFICATION.md` | package metadata |
| 3 | `GIT_DIFF.patch` | all tracked uncommitted changes vs HEAD |
| 4 | `FC-RC-FIX-009-REPORT.md` | deliverable of the covered task |
| 5 | `supabase/migrations/20261023090000_atomic_sense_ops.sql` | created by FC-RC-FIX-009 |
| 6 | `tests/database/atomic-sense-ops.test.ts` | created by FC-RC-FIX-009 |
| 7 | `tests/database/legacy-code-compat.test.ts` | created by FC-RC-FIX-009 |
| 8 | `server/supabase/supabase-database.ts` | modified by FC-RC-FIX-009 |
| 9 | `server/supabase/database.types.ts` | modified by FC-RC-FIX-009 |
| 10 | `server/supabase/supabase-repository.ts` | modified by FC-RC-FIX-009 |
| 11 | `server/vocabulary-catalog.ts` | modified by FC-RC-FIX-009 |
| 12 | `server/vocabulary-service.ts` | modified by FC-RC-FIX-009 |
| 13 | `shared/api.ts` | modified by FC-RC-FIX-009 |
| 14 | `tests/helpers/pg-vocabulary-database.ts` | modified by FC-RC-FIX-009 |
| 15 | `tests/helpers/fake-catalog.ts` | modified by FC-RC-FIX-009 |
| 16 | `tests/database/schema.test.ts` | modified by FC-RC-FIX-009 |
| 17 | `tests/server/import-senses.test.ts` | modified by FC-RC-FIX-009 (untracked file) |
| 18 | `tests/server/senses-api.test.ts` | carried untracked file (see §4) |
| 19 | `server/request-id.ts` | carried untracked file (see §4) |

All source files are the **complete current working-tree contents**, not partial excerpts. Because every deliverable
from FC-IMPL-005 through FC-RC-FIX-009 is uncommitted, a "file modified by FC-RC-FIX-009" also contains the earlier
tasks' changes to that same file; `GIT_DIFF.patch` shows the full delta vs HEAD for every tracked file, and
`FC-RC-008-REVIEW-PACKAGE.zip` (repository root) holds the state as of the task before this one.

---

## 2. Files created by FC-RC-FIX-009 (all included)

| File | What it is |
|---|---|
| `supabase/migrations/20261023090000_atomic_sense_ops.sql` | v14 additive migration: `reorder_vocabulary_senses`, `add_vocabulary_sense`, `restore_vocabulary_sense`, `create_vocabulary_with_senses`, `vocabulary_senses_sync_content` trigger, one-off legacy-column reconciliation, revokes/grants, `app_schema_version() = 14` |
| `tests/database/atomic-sense-ops.test.ts` | 17 tests: reorder atomicity/rollback/refusals, add & restore under the word's claim, legacy-column sync matrix, `create_vocabulary_with_senses` including rollback-leaves-nothing |
| `tests/database/legacy-code-compat.test.ts` | 6 tests: version-12 code executed against the newest schema (12-arg `create_vocabulary`, `update_vocabulary` patch, v12 column-list view reads live/trashed, trash via `vocabulary`, request-id repeat, cross-account isolation) |
| `FC-RC-FIX-009-REPORT.md` | complete 9-section report with READY recommendation |

## 3. Files modified by FC-RC-FIX-009 (all included, complete source)

| File | Change made by FC-RC-FIX-009 |
|---|---|
| `server/supabase/supabase-database.ts` | `LATEST_SCHEMA_VERSION = 14`; `NewCard.senses`; `createCard` routes to `create_vocabulary_with_senses` when senses are present (plain path never sends `p_senses`); `createSense`/`reorderSenses`/`restoreSense` become single `.rpc` calls; `P0002 → not_found`, `P0003 → stale` mapping; guards on those three raised to `< 14`; `NOT_FOUND_IN_DB`/`STALE_VERSION_IN_DB` constants |
| `server/supabase/database.types.ts` | typed `Functions` entries for the four new RPCs |
| `server/supabase/supabase-repository.ts` | `capabilitiesAt`: `senses >= 14`; `createEntry` passes `senses` through to `createCard` |
| `server/vocabulary-catalog.ts` | `NewEntry.senses?` — optional atomicity hint with its contract comment |
| `server/vocabulary-service.ts` | `create(request, senses?)`; `importBatch` carries derived-sense request ids into the row's own write **and always** runs the completion pass; stopped message names the interrupted row and the retry contract |
| `shared/api.ts` | `stopped` comment corrected: the row at `index` **was** attempted; the rows after it were not |
| `tests/helpers/pg-vocabulary-database.ts` | PGlite double mirrors the store: same four calls, same guards, same error mapping |
| `tests/helpers/fake-catalog.ts` | drops the `senses` field it cannot honour (fillSenses creates them, as before) |
| `tests/database/schema.test.ts` | one test **setup** corrected (seeds content through the word's first sense instead of base columns only; no assertion weakened — see report §E) |
| `tests/server/import-senses.test.ts` | +7 tests: 6 failure-injection (createCard / createSense / archiveSense failures, owner intervention, owner edit, duplicate-id payload) and 1 schema-13 refusal test |

## 4. Carried untracked files included for evidence self-containment

Neither file was created or modified by FC-RC-FIX-009; both are untracked (they would not appear in `git diff`)
and are included because this task's evidence cites or depends on them:

- `tests/server/senses-api.test.ts` — the G2 matrix in `FC-RC-FIX-009-REPORT.md` cites its tests (primary edit,
  archive/restore/reorder, stale versions, v12-refusal, v12→latest upgrade). Created by FC-HARDEN-007.
- `server/request-id.ts` — imported by the included `server/vocabulary-service.ts` (`derivedRequestId`, the helper
  that makes import-sense request ids identical on both passes). Created by FC-HARDEN-007.

## 5. Full working-tree inventory vs HEAD at packaging time (37 entries before this ZIP)

**Included in this ZIP as full source (16):** the 4 created + 10 modified files of §2/§3, plus the 2 carried files of §4.

**In `GIT_DIFF.patch` only (15 tracked, modified by earlier tasks, unchanged by FC-RC-FIX-009):**
`docs/import-and-export.md`, `server/create-app.ts`, `server/export-service.ts`, `server/mock/mock-repository.ts`,
`shared/export-format.ts`, `shared/import.ts`, `shared/vocabulary.ts`, `src/components/WordDetailPanel.tsx`,
`src/lib/api-client.ts`, `src/pages/AddPage.tsx`, `src/pages/ImportPage.tsx`, `tests/client/import.test.tsx`,
`tests/client/vocabulary-pages.test.tsx`, `tests/helpers/fake-api.ts`, `tests/shared/import.test.ts`.
(Complete sources of these are in `FC-RC-008-REVIEW-PACKAGE.zip → SOURCE/`.)

**Untracked, excluded as out of delta scope (9):**
`FC-HARDEN-007-REPORT.md`, `FC-RC-008-REVIEW-PACKAGE.zip`, `FC-VERIFY-006-REPORT.md`, `OPENCODE_AUDIT_REPORT.md`
(prior deliverables, at repository root), `supabase/migrations/20261022090000_vocabulary_senses.sql` (v13, the
predecessor this migration builds on; also in the FC-RC-008 package), `tests/client/sense-ui.test.tsx`
(FC-HARDEN-007 UI tests), plus the three metadata files that are part of this ZIP's contents §1.

**Expected 38th entry after packaging:** `FC-RC-010-DELTA-REVIEW.zip` itself (this deliverable, repository root).

## 6. Exclusions applied

- **Secrets / environment:** no `.env`, `.env.*`, credential, key or token file exists in or was copied into this
  package (whitelist packaging — only the 19 named entries).
- **`node_modules/`, `.git/` internals, build outputs (`dist/`, `dist-server/`)**: excluded.
- **Database backups and user data**: no `*.db`, `*.sqlite`, `*.dump`, `*.backup` or export/data file included;
  test databases are created per-run in the system temp area and are never in the repository.
- **Binary prior package**: `FC-RC-008-REVIEW-PACKAGE.zip` is referenced, not nested.
