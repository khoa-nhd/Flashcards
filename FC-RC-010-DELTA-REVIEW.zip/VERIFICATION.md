# VERIFICATION — FC-RC-010 packaging of the FC-RC-FIX-009 delta

**Date:** 2026-10-16 · **Machine:** Windows (win32), PowerShell 7 (pwsh)
**Repository:** `D:\MinhTriet\LT\Project2\Flashcards`, branch `newfeature`, HEAD `8d76720ab0cc21771602574a9aa161d5dcbd9e15` (unchanged, zero commits)
**Toolchain:** Node v24.22.0, npm 11.19.1 (installed at `D:\New folder\`; each command below was run after `$env:PATH += ";D:\New folder"`), vitest 5.0.3, vite 8.3.4, esbuild, PGlite (PostgreSQL compiled to WASM, one database per test file)
**Nature of this task:** evidence packaging only — no application code, migration, test or configuration file was modified; no migration was rerun; no commit, push, deploy or dependency installation was performed.

---

## 1. Verification of the covered work (FC-RC-FIX-009) — exact commands and results

### Baseline (gate G0, captured before FC-RC-FIX-009 began)

```
npx vitest run          →  D:\rcfix_g0_baseline.txt
  Test Files  81 passed (81)
  Tests  1759 passed | 3 skipped (1762)          exit 0
```
(The 3 skips are the pre-existing fixture-gated backup-import tests.)

### Final gates (gate G4, run 2026-10-16 20:25, in one chain after `$env:PATH += ";D:\New folder"`)

```
npx tsc --noEmit
  → 0 errors (no output, exit 0)

npx eslint .
  → 0 problems (no output, exit 0)

npx vitest run
  → Test Files  83 passed (83)
    Tests  1793 passed | 3 skipped (1796)        0 failed
    Duration ~163 s                              exit 0
    (baseline 1759 + 30 tests added by FC-RC-FIX-009 + 4 tests the schema-14
     bump adds automatically to gateway-versions = 1793)

npm run build
  → npm run typecheck (tsc --noEmit)  → 0 errors
    vite build                        → ✓ 287 modules transformed; dist/index.html
                                        0.94 kB, 5 assets (chunk-size >500 kB warning
                                        is pre-existing from the FC-VERIFY-006 baseline)
    build:server (esbuild)            → dist-server/index.js 253.7 kB
    exit 0
```

### Targeted runs of the files this delta adds or changes

```
npx vitest run tests/database/atomic-sense-ops.test.ts tests/database/legacy-code-compat.test.ts
  → Test Files 2 passed (2);  Tests 23 passed (23)

npx vitest run tests/server/import-senses.test.ts tests/server/senses-api.test.ts \
               tests/server/gateway-versions.test.ts tests/server/undo-api.test.ts
  → Test Files 4 passed (4);  Tests 127 passed (127)

npx vitest run tests/server/import-senses.test.ts tests/server/import-export-api.test.ts \
               tests/server/vocabulary-service.test.ts
  → Test Files 3 passed (3);  Tests 84 passed (84)

npx vitest run tests/server/import-senses.test.ts   → 1 file passed; 22 passed (incl. 6 failure-injection + 1 schema-13 refusal)
npx vitest run tests/database/schema.test.ts        → 1 file passed; 44 passed
```

### Packaging-time repository checks (read-only)

```
git rev-parse --short HEAD   → 8d76720        (unchanged before and after packaging)
git status --short           → 24 modified, 13 untracked before this ZIP;
                               the ZIP itself is the expected 38th entry (?? FC-RC-010-DELTA-REVIEW.zip)
git diff HEAD --stat         → 24 files changed, 2111 insertions(+), 78 deletions(-)
git diff HEAD --no-color --output=<staging>\GIT_DIFF.patch   → 142 875 bytes (UTF-8, byte-verbatim from git)
```

### Archive integrity procedure (executed after ZIP creation)

1. List all entries of `FC-RC-010-DELTA-REVIEW.zip` — expected **19 files** exactly as listed in
   `FILE_MANIFEST.md §1`; zero entries matching `.env`, `node_modules/`, `.git/`, `dist/`, `*.db`, `*.dump`,
   `*.backup`, `*.zip`.
2. Extract to a fresh temp directory and compare **SHA-256 of every extracted file against its staged source** —
   all 19 must match byte-for-byte.
3. Result of both steps is recorded in the FC-RC-010 delivery response (a verification performed *after* creation
   cannot be embedded in the archive without invalidating the archive it describes).

---

## 2. Unresolved limitations (carried unchanged from FC-RC-FIX-009 §G)

| ID | Limitation | Status |
|---|---|---|
| R-1 | The v14 functions were executed on PGlite (real PostgreSQL/WASM), never on hosted/managed PostgreSQL | **UNVERIFIED** locally — migration push BLOCKED (CP-2/CP-5); nothing is deployed |
| R-2 | Genuinely **simultaneous-transaction** races: the local store is single-connection (sessions serialised), no `psql`/`docker`/Postgres service exists, installing one needs CP-3 (not requested). Sequential-collision coverage is complete and passing; overlapping coverage is not claimed | **UNVERIFIED** |
| R-3 | The fix exists only in this working tree — migration never pushed, nothing deployed | **BLOCKED** by contract (CP-2/CP-5) |
| R-4 | The PostgREST gateway hop in front of the four functions (`.rpc`, SQLSTATE propagation, `p_senses` argument shape) was not re-executed locally; typing + the proven v13 `P0003` precedent stand in for it | **UNVERIFIED** locally |
| R-5 | Documented deadlock window: app-layer archive/update take sense-row→word locks, the new functions take word→sense; PostgreSQL detects `40P01`, one side aborts → explicit 503, nothing corrupted; all required operation pairs are word-first and cannot deadlock among themselves | Accepted, documented |
| R-6 | Behaviour change: schema-13 databases now refuse sense work (`409 not_supported`) instead of being served by code that would drift — intended, tested (`migrations: 13`), needs Product visibility | Documented |
| R-7 | Real-browser E2E not run | **BLOCKED** (CP-3) |
| R-8 | No deployment or rollback drill | **BLOCKED** by task rules |

**Scope statements that remain true:**

- **PGlite vs PostgreSQL:** PGlite *is* PostgreSQL (WASM) — SQL, plpgsql, triggers, `raise … using errcode`,
  `select … for update`, unique indexes and RLS were genuinely exercised by every test above. What it cannot give
  locally is a second concurrent connection and the PostgREST gateway in front of the functions.
- **Disclosed test change:** `tests/database/schema.test.ts > update_vocabulary` had its `beforeEach` **setup**
  corrected (content is now seeded through the word's first sense, the way the app stores it) because the old
  setup created exactly the drift RC-002 forbids. No assertion was weakened.
- **Pre-existing noise:** one Vite chunk-size warning (present since the FC-VERIFY-006 baseline); the line
  `Not implemented: navigation to another Document` printed by the test environment.
- **`GIT_DIFF.patch` scope:** tracked changes only (24 files). Untracked files — which `git diff` cannot contain —
  are included as complete sources in this ZIP and identified in `FILE_MANIFEST.md §2/§4/§5`.

---

## 3. Package construction record

- Staging directory (outside the repository): `C:\Users\Admin\AppData\Local\Temp\opencode\fc-rc-010\package\`
- Files copied byte-for-byte from the working tree (`Copy-Item -LiteralPath`), 16 repo files, 371 851 bytes total.
- `GIT_DIFF.patch` written by git itself (`--output=`) to avoid any shell transcoding of UTF-8 content.
- Archive created with .NET `ZipFile.CreateFromDirectory` (deflate, forward-slash entry names) at
  `D:\MinhTriet\LT\Project2\Flashcards\FC-RC-010-DELTA-REVIEW.zip`.
- Excluded by whitelist construction: secrets/`.env`, `node_modules`, `.git` internals, build outputs, database
  backups, user data, prior binary packages.
