# FC-RC-008 — Review Package File Manifest

Package root files were created for this review and have no original repository path. Every other entry keeps its original repository-relative path under `SOURCE/`.

| Package path | Original repository path | Bytes | Origin |
|---|---|---|---|
| `CHANGE_SUMMARY.md` | *(generated for this package)* | 9878 | generated |
| `GIT_DIFF.patch` | *(generated for this package)* | 131249 | generated |
| `VERIFICATION.md` | *(generated for this package)* | 5542 | generated |
| `FILE_MANIFEST.md` | *(generated for this package)* | *(self)* | generated |
| `SOURCE/docs/import-and-export.md` | `docs/import-and-export.md` | 12520 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/FC-HARDEN-007-REPORT.md` | `FC-HARDEN-007-REPORT.md` | 27287 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/FC-VERIFY-006-REPORT.md` | `FC-VERIFY-006-REPORT.md` | 25241 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/OPENCODE_AUDIT_REPORT.md` | `OPENCODE_AUDIT_REPORT.md` | 13566 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/server/create-app.ts` | `server/create-app.ts` | 27798 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/export-service.ts` | `server/export-service.ts` | 3058 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/mock/mock-repository.ts` | `server/mock/mock-repository.ts` | 29875 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/request-id.ts` | `server/request-id.ts` | 885 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/server/supabase/database.types.ts` | `server/supabase/database.types.ts` | 12171 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/supabase/supabase-database.ts` | `server/supabase/supabase-database.ts` | 57030 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/supabase/supabase-repository.ts` | `server/supabase/supabase-repository.ts` | 18648 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/vocabulary-catalog.ts` | `server/vocabulary-catalog.ts` | 4448 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/server/vocabulary-service.ts` | `server/vocabulary-service.ts` | 24359 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/shared/api.ts` | `shared/api.ts` | 39848 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/shared/export-format.ts` | `shared/export-format.ts` | 3742 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/shared/import.ts` | `shared/import.ts` | 18820 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/shared/vocabulary.ts` | `shared/vocabulary.ts` | 2796 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/src/components/WordDetailPanel.tsx` | `src/components/WordDetailPanel.tsx` | 40315 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/src/lib/api-client.ts` | `src/lib/api-client.ts` | 25852 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/src/pages/AddPage.tsx` | `src/pages/AddPage.tsx` | 22622 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/src/pages/ImportPage.tsx` | `src/pages/ImportPage.tsx` | 27268 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/supabase/migrations/20261022090000_vocabulary_senses.sql` | `supabase/migrations/20261022090000_vocabulary_senses.sql` | 15748 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/tests/client/import.test.tsx` | `tests/client/import.test.tsx` | 21899 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/tests/client/sense-ui.test.tsx` | `tests/client/sense-ui.test.tsx` | 10857 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/tests/client/vocabulary-pages.test.tsx` | `tests/client/vocabulary-pages.test.tsx` | 29726 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/tests/database/schema.test.ts` | `tests/database/schema.test.ts` | 34788 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/tests/helpers/fake-api.ts` | `tests/helpers/fake-api.ts` | 26272 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/tests/helpers/fake-catalog.ts` | `tests/helpers/fake-catalog.ts` | 8906 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/tests/helpers/pg-vocabulary-database.ts` | `tests/helpers/pg-vocabulary-database.ts` | 30029 | tracked modification (also in GIT_DIFF.patch) |
| `SOURCE/tests/server/import-senses.test.ts` | `tests/server/import-senses.test.ts` | 22681 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/tests/server/senses-api.test.ts` | `tests/server/senses-api.test.ts` | 26226 | untracked NEW file — full copy (not in GIT_DIFF.patch) |
| `SOURCE/tests/shared/import.test.ts` | `tests/shared/import.test.ts` | 14767 | tracked modification (also in GIT_DIFF.patch) |

Totals: **32 repository files** under SOURCE/ (24 tracked modifications + 8 untracked new files) plus 4 generated package documents.

Excluded by design: `.env`/credentials, API keys, `node_modules`, `.git` internals, `dist`/`dist-server` builds, database backups, user data, unrelated personal files. No binary files are packaged; every entry is plain text (`.ts`, `.tsx`, `.sql`, `.md`, `.patch`).
