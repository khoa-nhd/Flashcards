# FC-RC-008 — Change Summary

**Package:** Vocabulary Foundation — Technical Review Evidence Package
**Repository:** Vocabulary Flashcards
**Branch / HEAD:** `newfeature` / `8d76720ab0cc21771602574a9aa161d5dcbd9e15`
**Contents:** all working-tree changes made under three tasks —
**FC-IMPL-005** (v13 multi-sense foundation), **FC-VERIFY-006** (verification and corrections)
and **FC-HARDEN-007** (data-integrity and release hardening).
**Package task itself (FC-RC-008):** evidence collection only — **no application code was modified.**

Working-tree summary at packaging time:

```
24 tracked files changed, 2007 insertions(+), 38 deletions(-)     (GIT_DIFF.patch)
 8 untracked files (implementation, migration, tests, reports)    (full copies under SOURCE/)
0 commits made; HEAD unchanged; no push/reset/clean/deploy
```

Note on `GIT_DIFF.patch`: `git diff` only shows tracked files. The eight untracked files —
including the v13 migration, `server/request-id.ts`, and three test files — **do not appear in
the patch**; their complete contents are included as copies under `SOURCE/`.

---

## 1. What changed, by layer

### 1.1 Database — v13 migration (new file, `supabase/migrations/20261022090000_vocabulary_senses.sql`, 318 lines)

- `app_schema_version()` → **13** (the capability signal the app reads).
- New table **`vocabulary_senses`**: `user_id default auth.uid()`, `vocabulary_id` FK with
  cascade, `position smallint >= 0` with `unique (vocabulary_id, position)`, nullable
  meaning/definition/example with length checks, `archived_at`, `version`, `request_id`,
  `unique (user_id, request_id)`.
- Indexes; **RLS enabled**; grants `select/insert/update` to `authenticated` only — **no DELETE grant**.
- `vocabulary.senses_version` added (`add column ... not null default 0` — rewrite-safe).
- **Backfill**: one primary sense (position 0) for every existing row with any content —
  **soft-deleted (trashed) rows included** so restore behaves; content-free rows get none.
- `vocabulary_cards` view replaced: all 23 prior columns keep name, type and position;
  `meaning`/`definition`/`example` become the first *live* sense (same column names/types);
  `senses_version` and `senses` appended at the end.
- `create_vocabulary` / `update_vocabulary` replaced with **identical parameter lists**
  (old clients bind unchanged): create inserts the primary sense; update writes a changed
  meaning/definition/example through to the first live sense (or appends a sense if the word
  had none) and bumps versions. The schedule path is explicitly unchanged. Execute grants
  restored at the end.
- Additive only: no `drop`; recovery = restore from backup (project convention: no down-migrations).

### 1.2 Shared contracts

| File | Change |
|---|---|
| `shared/vocabulary.ts` (+18) | New `Sense` interface (id, position, meaning, definition, example, archived, version) — pure type addition |
| `shared/api.ts` (+112) | `senseSchema`; add/update/reorder/archive/restore request+response schemas; `senses`/`sensesVersion` on the entry schema; `capabilities.senses` (default false); `MAX_SENSES = 25` (single source of truth); `importSenseSchema` + optional `senses` on `importItemSchema` |
| `shared/export-format.ts` (+3) | `ExportedWord.senses: Sense[]` (empty array for pre-sense exports) |
| `shared/import.ts` (+71) | JSON parser carries each row's `senses` (record metadata `id`/`position`/`version` stripped — they belong to the source account); `toImportRows` 4th parameter; `rowProblem` validates senses in the browser (count ≤ 25, field ≤ 6000) before anything is sent |

### 1.3 Server

| File | Change |
|---|---|
| `server/vocabulary-service.ts` (+198) | `create()` writes the word's primary sense; sense operations (list/get/add/update/reorder/archive/restore) through the single operation-endpoint write path with compare-and-set `version` → stale becomes **409 conflict**, `P0003` unique violation → 409; add is **idempotent by `requestId`**; legacy whole-word PATCH writes through to the first live sense and honours `expectSensesVersion`; **`importBatch` multi-sense restore**: capability gate (a row carrying senses on a pre-v13 database is refused whole with a message — the word is never created stripped of senses), senses become the content when present (row's four content fields are not stored twice), `fillSenses` creates each sense in order under the same `sense:<id>` lock the editor uses with request ids **derived deterministically** from the row's id (`server/request-id.ts`, sha1/uuid-v5-shaped) — a resent batch or an interrupted run lands on the same records instead of doubling them; only archives senses flagged archived (never updates or un-archives existing data) |
| `server/vocabulary-catalog.ts` (+23) | `SenseOperations` interface (the contract every store implements) |
| `server/create-app.ts` (+46) | Seven sense routes: `GET /api/vocabulary/:id/senses`, `PATCH …/senses/order`, `GET/POST …/senses`, `PATCH/POST archive`, `POST …/senses/:senseId/restore` |
| `server/supabase/supabase-database.ts` (+254) | Sense implementation in SQL: request-id lookup then `UNIQUE_VIOLATION` retry for idempotent create; position rules — add appends, restore-to-end, reorder packs archived behind; version CAS; schema < 13 → `schema_missing` (surfaced as 409 `not_supported`) |
| `server/supabase/supabase-repository.ts` (+66) | Row mapping carries `senses`/`sensesVersion`; `toSense` mapping; `capabilities.senses = schemaVersion >= 13`; `expectSensesVersion` passthrough |
| `server/supabase/database.types.ts` (+56) | Generated types for `vocabulary_senses` |
| `server/mock/mock-repository.ts` (+167) | Mock sense store with the same semantics (request-id idempotency map) |
| `server/export-service.ts` (+1) | Account export includes `senses` per word |
| `server/request-id.ts` (new) | `derivedRequestId(parent, label)` — deterministic child request ids |

### 1.4 Client

| File | Change |
|---|---|
| `src/lib/api-client.ts` (+77) | Sense methods: list/get/add/update/reorder/archive/restore |
| `src/components/WordDetailPanel.tsx` (+398) | Word Profile sense editor: lists senses (archived included), add/edit with versioned save, reorder up/down, archive/restore, clear conflict message on 409; the legacy meaning/definition/example form, its validation and duplicate handling are kept as they were |
| `src/pages/AddPage.tsx` (+23) | A duplicate word is offered as **“Add as sense to …”** |
| `src/pages/ImportPage.tsx` (+15) | Senses carried into import items; preview shows “· N senses”; help copy updated; nothing is sent before the owner confirms |

### 1.5 Tests

- **New files:** `tests/server/senses-api.test.ts` (21 tests), `tests/server/import-senses.test.ts`
  (15 round-trip tests), `tests/client/sense-ui.test.tsx` (10 tests).
- **Extended:** `tests/client/import.test.tsx` (+1: export → preview → confirm → send journey),
  `tests/client/vocabulary-pages.test.tsx` (+1: word-save conflict feedback), `tests/database/schema.test.ts`
  (RLS/grants/no-DELETE for `vocabulary_senses`, isolation list), helpers `fake-api`/`fake-catalog`/
  `pg-vocabulary-database` (sense support in test doubles), `tests/shared/import.test.ts` (+4).
- **Suite growth:** 1735 → **1759** passing (+24); skips unchanged at 3 (fixture-gated
  backup-import describe, pre-existing).

### 1.6 Documentation and reports

- `docs/import-and-export.md`: export table lists the `senses` field; “Moving words to another
  account” rewritten — a full JSON export restores **every sense in order with archive state**;
  no-silent-overwrite rules; CSV and pre-sense JSON restore the leading sense only; the result
  is explicitly a **vocabulary-content restore, not a full-account recovery** (schedules,
  history, collections and settings require a database backup).
- Reports (untracked, full copies in `SOURCE/`): `FC-VERIFY-006-REPORT.md`,
  `FC-HARDEN-007-REPORT.md`; `OPENCODE_AUDIT_REPORT.md` is a pre-existing project audit
  (2026-10-14, predates these tasks) included as working-tree context — both task reports
  remain authoritative.

---

## 2. Impact analysis — Review, FSRS, Undo, Practice, RLS, legacy compatibility

- **Review / FSRS / Undo / Practice:** no source file of those modules appears in the diff
  (git status shows none). Shared changes are purely additive (a new `Sense` interface, one
  export field, an optional import field). The full test suite — including every review,
  FSRS, undo and practice suite — is green at **1759 passed / 0 failed** on this tree.
  The word form's behaviour (validation, duplicates, schedule fields) is unchanged and its
  existing tests still pass; only the *sense* editing UI is new.
- **RLS:** the new table is RLS-enabled with owner-only access, `auth.uid()` default, no
  DELETE grant; `tests/database/schema.test.ts` asserts RLS, exact grant list, no-DELETE and
  cross-user invisibility; server tests additionally assert cross-account 404s, including
  after an import restore.
- **Legacy compatibility:** the migration is additive (column with default, new table,
  view keeps all 23 prior columns in place and appends two, write functions keep identical
  parameter lists). New code against a pre-v13 database: sense features report off
  (`capabilities.senses=false`), sense operations are refused with `not_supported`, import
  rows carrying senses are refused whole while legacy rows import unchanged. Old exports
  (no `senses` field) and CSV import to a single leading sense. The v12→v13 upgrade was
  executed on a populated store **including a trashed word** (backfill reaches it).
- **What did not change:** `package.json` (no installs), no `.env` or credentials, the
  Backup/Notion backup system, scheduler/review/practice modules, and no migration was
  pushed to any environment.
