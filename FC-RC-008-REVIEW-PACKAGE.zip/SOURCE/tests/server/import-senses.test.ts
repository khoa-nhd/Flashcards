/**
 * Restoring multi-sense vocabulary through the supported restore path: the
 * account export, read back in the way the Import page reads a file. What has
 * to survive the round trip is every sense, in the order the owner kept them,
 * with each archive state; what must never happen is a doubled retry, a
 * touched-over existing word, or a word imported stripped of the senses the
 * file listed. The boundary is stated by the tests themselves: content comes
 * back, schedules and history do not — a restore adds words, it is not a
 * full-account recovery.
 */
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import {
  entryResponseSchema,
  importResponseSchema,
  vocabularyListResponseSchema,
  type ImportResponse,
  type VocabularyEntry,
} from '../../shared/api.js';
import type { AccountExport } from '../../shared/export-format.js';
import {
  checkRows,
  guessMapping,
  parseImportText,
  rowProblem,
  toImportRows,
  type ImportItem,
} from '../../shared/import.js';
import { toCsv } from '../../src/lib/export.js';
import { call, createSupabaseTestApp, createTestUser, newId, type TestApp, type TestUser } from '../helpers/supabase-app.js';
import { createTestDatabase, type TestDatabase } from '../helpers/test-database.js';

let db: TestDatabase;
let alice: TestUser;
let bob: TestUser;

beforeAll(async () => {
  db = await createTestDatabase();
}, 60_000);

afterAll(async () => {
  await db.close();
});

beforeEach(async () => {
  await db.admin('delete from auth.users');
  alice = await createTestUser(db, 'alice');
  bob = await createTestUser(db, 'bob');
});

const TODAY = '2026-10-11';
const on = (day = TODAY) =>
  createSupabaseTestApp(db, [alice, bob], { now: () => new Date(`${day}T05:00:00Z`) });

async function addWord(app: TestApp, user: TestUser, input: Record<string, unknown>): Promise<VocabularyEntry> {
  const response = await call(app, user, '/api/vocabulary', { method: 'POST', body: { requestId: newId(), ...input } });
  expect(response.status, await response.clone().text()).toBe(201);
  return entryResponseSchema.parse(await response.json()).entry;
}

async function fetchEntry(app: TestApp, user: TestUser, id: string): Promise<VocabularyEntry> {
  const response = await call(app, user, `/api/vocabulary/${id}`);
  expect(response.status).toBe(200);
  return entryResponseSchema.parse(await response.json()).entry;
}

const addSense = (app: TestApp, user: TestUser, wordId: string, body: Record<string, unknown>) =>
  call(app, user, `/api/vocabulary/${wordId}/senses`, { method: 'POST', body: { requestId: newId(), ...body } });

const post = (app: TestApp, user: TestUser | null, items: unknown) =>
  call(app, user, '/api/vocabulary/import', { method: 'POST', body: { items } });

async function imported(app: TestApp, user: TestUser, items: unknown[]): Promise<ImportResponse> {
  const response = await post(app, user, items);
  expect(response.status, await response.clone().text()).toBe(200);
  return importResponseSchema.parse(await response.json());
}

const wordsOf = async (app: TestApp, user: TestUser) =>
  vocabularyListResponseSchema.parse(await (await call(app, user, '/api/vocabulary')).json()).entries;

const exportOf = async (app: TestApp, user: TestUser) =>
  (await (await call(app, user, '/api/export')).json()) as AccountExport;

/** What a round trip has to reproduce: position, content and archive state — not ids. */
const sensesOf = (entry: VocabularyEntry) =>
  entry.senses.map(({ position, meaning, definition, example, archived }) => ({
    position,
    meaning,
    definition,
    example,
    archived,
  }));

const senseIdsOf = (entry: VocabularyEntry) => entry.senses.map((sense) => sense.id);

/**
 * Reads an export exactly the way the Import page reads a file, through the
 * same shared pipeline, and returns the items it would send — kept, so a
 * retry can resend the identical rows with their identical request ids.
 */
async function planRestore(
  app: TestApp,
  user: TestUser,
  text: string,
  options: { forceDuplicates?: boolean; hasHeader?: boolean } = {},
): Promise<{ rows: ReturnType<typeof checkRows>; items: ImportItem[] }> {
  const parsed = parseImportText(text);
  const hasHeader = options.hasHeader ?? false;
  const header = parsed.header ?? (hasHeader ? parsed.rows[0]! : null);
  const mapping = guessMapping((parsed.rows[0] ?? header ?? []).length, header);
  const rows = checkRows(toImportRows(parsed.rows, mapping, hasHeader, parsed.senses), await wordsOf(app, user));
  const items: ImportItem[] = rows
    .filter(
      (row) =>
        row.status === 'new' ||
        ((row.status === 'duplicate' || row.status === 'repeated') && options.forceDuplicates === true),
    )
    .map((row) => ({
      requestId: newId(),
      word: row.word,
      ...(row.meaning === null ? {} : { meaning: row.meaning }),
      ...(row.definition === null ? {} : { definition: row.definition }),
      ...(row.example === null ? {} : { example: row.example }),
      ...(row.dateAdded === null ? {} : { dateAdded: row.dateAdded }),
      ...(row.status === 'new' ? {} : { allowDuplicate: true }),
      ...(row.senses === undefined ? {} : { senses: row.senses }),
    }));
  return { rows, items };
}

async function restore(app: TestApp, user: TestUser, text: string, options?: Parameters<typeof planRestore>[3]) {
  const planned = await planRestore(app, user, text, options);
  const result = planned.items.length === 0 ? null : await imported(app, user, planned.items);
  return { ...planned, result };
}

/** A word with three senses: the leading one, and two more added behind it. */
async function seedBank(app: TestApp): Promise<VocabularyEntry> {
  const word = await addWord(app, alice, {
    word: 'bank',
    meaning: 'ngân hàng',
    definition: 'A business that keeps money safe.',
    dateAdded: '2026-09-01',
    mastery: 6,
    reviewDate: '2026-10-20',
  });
  await addSense(app, alice, word.id, { meaning: 'bờ sông', example: 'They sat on the bank.' });
  await addSense(app, alice, word.id, { definition: 'To put money into an account.' });
  return fetchEntry(app, alice, word.id);
}

describe('restoring a multi-sense vocabulary from its own export', () => {
  it('brings back a word with a single sense exactly as it was stored, as content', async () => {
    const app = on();
    const source = await addWord(app, alice, {
      word: 'candid',
      meaning: 'thẳng thắn',
      definition: 'Honest and direct.',
      example: 'He gave a candid answer.',
      dateAdded: '2026-09-01',
      mastery: 7,
      reviewDate: '2026-10-20',
    });
    const { result } = await restore(app, bob, JSON.stringify(await exportOf(app, alice)));
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported']);

    const restored = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    expect(restored.word).toBe('candid');
    expect(sensesOf(restored)).toEqual(sensesOf(source));
    expect(restored).toMatchObject({ dateAdded: '2026-09-01' });
    // The boundary of a content restore: no schedule is invented for it.
    expect(restored.id).not.toBe(source.id);
    expect([restored.mastery, restored.reviewDate]).toEqual([1, null]);
    expect(await db.admin('select count(*)::int as count from public.review_logs')).toEqual([{ count: 0 }]);
  });

  it('brings back every sense of a word, each with its own content', async () => {
    const app = on();
    const source = await seedBank(app);
    expect(source.senses).toHaveLength(3);

    const { result } = await restore(app, bob, JSON.stringify(await exportOf(app, alice)));
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported']);

    const restored = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    expect(sensesOf(restored)).toEqual(sensesOf(source));
    expect(restored.sensesVersion).toBe(3);
  });

  it('keeps an order the owner changed, not the order the senses were added in', async () => {
    const app = on();
    const word = await seedBank(app);
    const before = (await fetchEntry(app, alice, word.id)).senses;
    // Move the third sense to the front, then the first one last.
    const reorder = await call(app, alice, `/api/vocabulary/${word.id}/senses/order`, {
      method: 'PATCH',
      body: { senseIds: [before[2]!.id, before[0]!.id, before[1]!.id], ifMatch: (await fetchEntry(app, alice, word.id)).sensesVersion },
    });
    expect(reorder.status).toBe(200);
    const reordered = await fetchEntry(app, alice, word.id);
    expect(reordered.senses.map((sense) => sense.id)).toEqual([before[2]!.id, before[0]!.id, before[1]!.id]);

    const { result } = await restore(app, bob, JSON.stringify(await exportOf(app, alice)));
    const restored = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    // Same sequence after the restore, although the ids are new.
    expect(restored.senses.map(senseOfContent)).toEqual(reordered.senses.map(senseOfContent));
    expect(restored.senses.map((sense) => sense.position)).toEqual([0, 1, 2]);
  });

  it('keeps archived senses flagged, and the first live sense as the shown meaning', async () => {
    const app = on();
    const word = await seedBank(app);
    const first = (await fetchEntry(app, alice, word.id)).senses[0]!;
    const archive = await call(app, alice, `/api/vocabulary/${word.id}/senses/${first.id}/archive`, {
      method: 'POST',
      body: { ifMatch: first.version },
    });
    expect(archive.status).toBe(200);
    const source = await fetchEntry(app, alice, word.id);
    expect(sensesOf(source).map((sense) => sense.archived)).toEqual([true, false, false]);
    expect(source.meaning).toBe('bờ sông');

    const { result } = await restore(app, bob, JSON.stringify(await exportOf(app, alice)));
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported']);

    const restored = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    expect(sensesOf(restored)).toEqual(sensesOf(source));
    expect(restored.meaning).toBe('bờ sông');
    // The archived one is still there, only out of the way.
    expect(restored.senses[0]).toMatchObject({ archived: true, position: 0 });
  });

  it('round-trips the minimal profiles: a bare word and a word with one field', async () => {
    const app = on();
    await addWord(app, alice, { word: 'empty' });
    await addWord(app, alice, { word: 'lone', meaning: 'đơn độc' });

    const { result } = await restore(app, bob, JSON.stringify(await exportOf(app, alice)));
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported', 'imported']);

    const entries = await wordsOf(app, bob);
    const bare = await fetchEntry(app, bob, entries.find((entry) => entry.word === 'empty')!.id);
    const single = await fetchEntry(app, bob, entries.find((entry) => entry.word === 'lone')!.id);
    expect(bare).toMatchObject({ meaning: null, definition: null, example: null, sensesVersion: 0 });
    expect(bare.senses).toEqual([]);
    expect(sensesOf(single)).toEqual([
      { position: 0, meaning: 'đơn độc', definition: null, example: null, archived: false },
    ]);
  });
});

const senseOfContent = ({ meaning, definition, example }: { meaning: string | null; definition: string | null; example: string | null }) =>
  `${meaning ?? ''}|${definition ?? ''}|${example ?? ''}`;

describe('files made before senses existed', () => {
  it('reads a JSON export without a senses field, restoring the one sense it names', async () => {
    const app = on();
    await seedBank(app);
    const exported = await exportOf(app, alice);
    const legacy = {
      ...exported,
      vocabulary: exported.vocabulary.map((word) =>
        Object.fromEntries(Object.entries(word).filter(([key]) => key !== 'senses')),
      ),
    };

    const { result } = await restore(app, bob, JSON.stringify(legacy));
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported']);

    const restored = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    // The file only names the leading content, so one sense comes back — the
    // documented limitation of reading a file made before senses existed.
    expect(restored.senses).toHaveLength(1);
    expect(sensesOf(restored)).toEqual([
      { position: 0, meaning: 'ngân hàng', definition: 'A business that keeps money safe.', example: null, archived: false },
    ]);
  });

  it('reads the CSV export, which carries only the shown meaning of each word', async () => {
    const app = on();
    const source = await seedBank(app);
    const csv = toCsv(await wordsOf(app, alice));

    const { rows, result } = await restore(app, bob, csv, { hasHeader: true });
    expect(rows.map((row) => row.status)).toEqual(['new']);
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported']);

    const restored = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    expect(restored.senses).toHaveLength(1);
    expect(sensesOf(restored)).toEqual([sensesOf(source)[0]]);
  });
});

describe('when the file is not right', () => {
  it('refuses each bad row on its own and writes none of it', async () => {
    const app = on();
    const item = (word: string, extra: Record<string, unknown> = {}) => ({ requestId: newId(), word, ...extra });
    const { results, stopped } = await imported(app, bob, [
      item('fine', { meaning: 'đúng' }),
      item('unknown-field', { senses: [{ meaning: 'x', surprise: true }] }),
      item('too-long', { senses: [{ meaning: 'x'.repeat(6001) }] }),
      item('too-many', { senses: Array.from({ length: 26 }, (_, index) => ({ meaning: `sense ${index}` })) }),
      item('not-an-array', { senses: 'nope' }),
      item('not-an-object', { senses: [{ meaning: 'ok' }, 'nope'] }),
    ]);
    expect(stopped).toBeNull();
    expect(results.map((row) => row.outcome)).toEqual([
      'imported',
      'invalid',
      'invalid',
      'invalid',
      'invalid',
      'invalid',
    ]);
    expect(results.slice(1).every((row) => (row.message ?? '').length > 0)).toBe(true);

    // Only the good row exists. None of the refused words were created.
    expect((await wordsOf(app, bob)).map((entry) => entry.word)).toEqual(['fine']);
  });

  it('spots an unusable sense in the file itself, before anything is sent', () => {
    const row = {
      line: 2,
      word: 'bank',
      meaning: null,
      definition: null,
      example: null,
      dateAdded: null,
      senses: [{ meaning: 'x'.repeat(6001) }],
    };
    expect(rowProblem(row)).toMatch(/longer than 6000/);
    expect(rowProblem({ ...row, senses: Array.from({ length: 26 }, () => ({ meaning: 'x' })) })).toMatch(/at most 25/);
    expect(rowProblem({ ...row, senses: [{ meaning: 'ok' }] })).toBeNull();
  });
});

describe('sending the same file again', () => {
  it('lands on the same words and the same senses instead of doubling them', async () => {
    const app = on();
    await seedBank(app);
    const { items } = await planRestore(app, bob, JSON.stringify(await exportOf(app, alice)));

    const first = await imported(app, bob, items);
    expect(first.results.map((row) => row.outcome)).toEqual(['imported']);
    const restored = await fetchEntry(app, bob, first.results[0]!.entry!.id);
    const idsAfterFirst = senseIdsOf(restored);

    // The identical rows, with their identical request ids — a retry.
    const second = await imported(app, bob, items);
    expect(second.results.map((row) => row.outcome)).toEqual(['already_imported']);
    const again = await fetchEntry(app, bob, restored.id);
    expect(senseIdsOf(again)).toEqual(idsAfterFirst);
    expect(again.sensesVersion).toBe(restored.sensesVersion);
    expect((await wordsOf(app, bob)).filter((entry) => entry.word === 'bank')).toHaveLength(1);
  });

  it('finishes a run that stopped between the word and its senses', async () => {
    const app = on();
    const requestId = newId();
    // What an interruption leaves behind: the word with its request id, no senses.
    const first = await call(app, bob, '/api/vocabulary', { method: 'POST', body: { requestId, word: 'bank' } });
    expect(first.status).toBe(201);
    const bare = entryResponseSchema.parse(await first.json()).entry;
    expect(bare.senses).toEqual([]);

    // The same row again, with its senses, as the Import page resends it.
    const senses = [
      { meaning: 'ngân hàng' },
      { meaning: 'bờ sông' },
      { definition: 'To put money into an account.' },
    ];
    const { results, stopped } = await imported(app, bob, [{ requestId, word: 'bank', senses }]);
    expect(stopped).toBeNull();
    expect(results[0]?.outcome).toBe('already_imported');
    const filled = await fetchEntry(app, bob, bare.id);
    expect(sensesOf(filled)).toEqual([
      { position: 0, meaning: 'ngân hàng', definition: null, example: null, archived: false },
      { position: 1, meaning: 'bờ sông', definition: null, example: null, archived: false },
      { position: 2, meaning: null, definition: 'To put money into an account.', example: null, archived: false },
    ]);
    const ids = senseIdsOf(filled);

    // And the retry after the retry changes nothing at all.
    const again = await imported(app, bob, [{ requestId, word: 'bank', senses }]);
    expect(again.results[0]?.outcome).toBe('already_imported');
    const settled = await fetchEntry(app, bob, bare.id);
    expect(senseIdsOf(settled)).toEqual(ids);
    expect(settled.sensesVersion).toBe(filled.sensesVersion);
  });
});

describe('restoring over words that are already there', () => {
  it('leaves an overlapping word untouched, and a chosen duplicate becomes its own copy', async () => {
    const app = on();
    await seedBank(app);
    const exported = await exportOf(app, alice);

    // Bob already has his own bank, with his own senses.
    const bobBank = await addWord(app, bob, { word: 'BANK', meaning: 'tiền gửi' });
    await addSense(app, bob, bobBank.id, { meaning: 'bờ sông' });
    const bobBefore = await fetchEntry(app, bob, bobBank.id);

    // Not chosen: the overlapping row is left out, so nothing is sent at all.
    const plain = await planRestore(app, bob, JSON.stringify(exported));
    expect(plain.rows.map((row) => row.status)).toEqual(['duplicate']);
    expect(plain.items).toEqual([]);
    expect(await fetchEntry(app, bob, bobBank.id)).toMatchObject({
      sensesVersion: bobBefore.sensesVersion,
    });
    expect(senseIdsOf(await fetchEntry(app, bob, bobBank.id))).toEqual(senseIdsOf(bobBefore));

    // Chosen: imported as a separate word, its senses and all; Bob's stays his.
    const chosen = await planRestore(app, bob, JSON.stringify(exported), { forceDuplicates: true });
    const result = await imported(app, bob, chosen.items);
    expect(result.results.map((row) => row.outcome)).toEqual(['imported']);

    const banks = await wordsOf(app, bob);
    expect(banks).toHaveLength(2);
    const after = await fetchEntry(app, bob, bobBank.id);
    expect(senseIdsOf(after)).toEqual(senseIdsOf(bobBefore));
    expect(after).toMatchObject({ meaning: 'tiền gửi', sensesVersion: bobBefore.sensesVersion });
    const copy = await fetchEntry(app, bob, result.results[0]!.entry!.id);
    expect(sensesOf(copy).map(senseOfContent)).toHaveLength(3);
    expect(copy.meaning).toBe('ngân hàng');
  });
});

describe('who the restore belongs to', () => {
  it('restores only into the account that imported, leaving the source as it was', async () => {
    const app = on();
    const source = await seedBank(app);
    const exported = await exportOf(app, alice);

    const { result } = await restore(app, bob, JSON.stringify(exported));
    const restoredId = result!.results[0]!.entry!.id;
    expect(restoredId).not.toBe(source.id);

    // The source account is exactly as it was: same word, same senses, same version.
    const after = await fetchEntry(app, alice, source.id);
    expect(senseIdsOf(after)).toEqual(senseIdsOf(source));
    expect(after.sensesVersion).toBe(source.sensesVersion);

    // And it cannot see Bob's copy: the row and its senses belong to Bob.
    expect((await call(app, alice, `/api/vocabulary/${restoredId}`)).status).toBe(404);
    expect((await call(app, alice, `/api/vocabulary/${restoredId}/senses`)).status).toBe(404);
  });

  it('brings a trashed word’s senses back with its content, as a live word', async () => {
    const app = on();
    const source = await seedBank(app);
    expect((await call(app, alice, `/api/vocabulary/${source.id}`, { method: 'DELETE' })).status).toBe(200);

    const exported = await exportOf(app, alice);
    expect(exported.counts).toMatchObject({ words: 0, wordsInTrash: 1 });

    const { result } = await restore(app, bob, JSON.stringify(exported));
    expect(result?.results.map((row) => row.outcome)).toEqual(['imported']);
    const back = await fetchEntry(app, bob, result!.results[0]!.entry!.id);
    expect(sensesOf(back)).toEqual(sensesOf(source));

    // The trash stayed where it was: Alice still has the word in it, untouched.
    const trash = (await (await call(app, alice, '/api/trash')).json()) as { entries: VocabularyEntry[] };
    expect(trash.entries.map((entry) => entry.word)).toEqual(['bank']);
    const stored = await db.admin(
      `select id from public.vocabulary_senses where vocabulary_id = '${source.id}' order by position`,
    );
    expect(stored.map((row) => row.id)).toEqual(senseIdsOf(source));
  });
});

describe('a database whose migration has not been run', () => {
  let behind: TestDatabase;
  let owner: TestUser;
  let legacy: TestApp;

  beforeAll(async () => {
    behind = await createTestDatabase({ migrations: 12 });
  }, 60_000);

  afterAll(async () => {
    await behind.close();
  });

  beforeEach(async () => {
    await behind.admin('delete from auth.users');
    owner = await createTestUser(behind, 'owner');
    legacy = createSupabaseTestApp(behind, [owner]);
  });

  it('refuses a row carrying senses instead of importing the word without them', async () => {
    const { results, stopped } = await imported(legacy, owner, [
      { requestId: newId(), word: 'plain', meaning: 'đơn giản' },
      { requestId: newId(), word: 'rich', meaning: 'sự phong phú', senses: [{ meaning: 'nghĩa mới' }] },
    ]);
    expect(stopped).toBeNull();
    expect(results.map((row) => row.outcome)).toEqual(['imported', 'invalid']);
    expect(results[1]?.message).toMatch(/cannot store multiple senses/i);
    // Nothing half-made: the refused word was never created.
    expect((await wordsOf(legacy, owner)).map((entry) => entry.word)).toEqual(['plain']);
  });
});
