// @vitest-environment jsdom
import { act, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it } from 'vitest';
import type { VocabularyEntry, VocabularyListResponse } from '../../shared/api.js';
import { App } from '../../src/App.js';
import { ApiError } from '../../src/lib/api-client.js';
import { createSettingsStore, type Settings } from '../../src/lib/settings.js';
import { createFakeApi, entry } from '../helpers/fake-api.js';
import { TODAY, deferred, pageId } from '../helpers/fixtures.js';

const WORDS = [
  entry(1, { word: 'serendipity', meaning: 'sự tình cờ', mastery: 2, reviewStatus: 'overdue', reviewDate: '2026-10-01', dateAdded: '2026-09-20' }),
  entry(2, { word: 'candid', meaning: 'thẳng thắn', definition: null, example: null, mastery: 10, reviewStatus: 'mastered', reviewable: false, dateAdded: '2026-08-01' }),
  entry(3, { word: 'alleviate', meaning: 'làm dịu', mastery: 5, reviewStatus: 'due_today', dateAdded: TODAY }),
];

interface Options {
  entries?: VocabularyEntry[];
  list?: Partial<VocabularyListResponse>;
  settings?: Partial<Settings>;
}

async function open(path: string, { entries = WORDS, list, settings }: Options = {}) {
  window.history.replaceState(null, '', path);
  const fake = createFakeApi({ entries, list });
  const store = createSettingsStore(null);
  if (settings) store.update(settings);
  const view = render(<App api={fake.api} settings={store} />);
  await waitFor(() => expect(fake.api.fetchVocabulary).toHaveBeenCalled());
  await screen.findAllByRole('heading');
  return { ...fake, user: userEvent.setup(), ...view };
}

beforeEach(() => {
  window.history.replaceState(null, '', '/');
});

const wordField = () => screen.getByLabelText(/^Word/);
const addButton = () => screen.getByRole('button', { name: /Add word|Saving/ });

describe('Add vocabulary', () => {
  it('creates a word and confirms it only after the server has', async () => {
    const { api, user } = await open('/add');
    const pending = deferred<VocabularyEntry>();
    api.createEntry.mockReturnValueOnce(pending.promise);

    await user.type(await screen.findByLabelText(/^Word/), 'luminous');
    await user.type(screen.getByLabelText('Vietnamese meaning'), 'sáng chói');
    await user.type(screen.getByLabelText('Definition'), 'full of light');
    await user.click(addButton());

    expect(api.createEntry).toHaveBeenCalledTimes(1);
    expect(api.createEntry.mock.calls[0]?.[0]).toMatchObject({
      word: 'luminous',
      meaning: 'sáng chói',
      definition: 'full of light',
      example: '',
      dateAdded: TODAY,
      mastery: 1,
      reviewDate: null,
    });
    expect(api.createEntry.mock.calls[0]?.[0].requestId).toMatch(/^[0-9a-f-]{36}$/);

    // Still saving: no success yet, and the form cannot be submitted again.
    expect(screen.queryByText(/was added/)).not.toBeInTheDocument();
    expect(addButton()).toBeDisabled();

    await act(async () => pending.resolve(entry(50, { word: 'luminous', meaning: 'sáng chói', dateAdded: TODAY })));
    expect(await screen.findByText(/was added/)).toHaveTextContent('luminous was added to your vocabulary.');
    // Ready for the next word, with the cursor back where typing starts.
    expect(wordField()).toHaveValue('');
    expect(screen.getByLabelText('Vietnamese meaning')).toHaveValue('');
    await waitFor(() => expect(wordField()).toHaveFocus());
  });

  it('shows the starting values a new word will get', async () => {
    await open('/add');
    expect(await screen.findByRole('button', { name: /Starting review settings/ })).toHaveTextContent(
      'Mastery 1 · no review date (due right away)',
    );
    expect(screen.getByLabelText('Date added')).toHaveValue(TODAY);
  });

  it('uses the configured defaults, whatever they are', async () => {
    const { api, user } = await open('/add', {
      list: { defaults: { mastery: 0, reviewDate: 'today' } },
    });
    await user.type(await screen.findByLabelText(/^Word/), 'zeal');
    await user.click(addButton());
    expect(api.createEntry.mock.calls[0]?.[0]).toMatchObject({ mastery: 0, reviewDate: TODAY });
  });

  it('requires a word and says so beside the field', async () => {
    const { api, user } = await open('/add');
    await user.click(await screen.findByRole('button', { name: 'Add word' }));
    expect(screen.getByText('Enter the word you want to add.')).toBeInTheDocument();
    expect(wordField()).toHaveAttribute('aria-invalid', 'true');
    await user.type(wordField(), '   ');
    await user.click(addButton());
    expect(api.createEntry).not.toHaveBeenCalled();
  });

  it('rejects an invalid mastery or date before anything is sent', async () => {
    const { api, user } = await open('/add');
    await user.type(await screen.findByLabelText(/^Word/), 'zeal');
    await user.click(screen.getByRole('button', { name: /Starting review settings/ }));
    await user.clear(screen.getByLabelText('Mastery'));
    await user.type(screen.getByLabelText('Mastery'), '11');
    await user.click(addButton());
    expect(screen.getByText('Mastery must be a whole number from 0 to 10.')).toBeInTheDocument();
    expect(api.createEntry).not.toHaveBeenCalled();

    fireEvent.change(screen.getByLabelText('Mastery'), { target: { value: '3' } });
    fireEvent.change(screen.getByLabelText('Date added'), { target: { value: '' } });
    await user.click(addButton());
    expect(screen.getByText('Choose the date the word was added.')).toBeInTheDocument();
    expect(api.createEntry).not.toHaveBeenCalled();
  });

  it('warns about a word that already exists, ignoring case and spacing', async () => {
    const { api, user } = await open('/add');
    await user.type(await screen.findByLabelText(/^Word/), '  SerenDipity ');
    expect(screen.getByText(/Already in your vocabulary/)).toHaveTextContent('serendipity');

    await user.click(addButton());
    const warning = screen.getByRole('alert');
    expect(warning).toHaveTextContent('This word may already be in your vocabulary');
    expect(within(warning).getByText('sự tình cờ')).toBeInTheDocument();
    expect(api.createEntry).not.toHaveBeenCalled();
  });

  it('lets the user cancel a duplicate or create it on purpose', async () => {
    const { api, user } = await open('/add');
    await user.type(await screen.findByLabelText(/^Word/), 'candid');
    await user.click(addButton());
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
    expect(api.createEntry).not.toHaveBeenCalled();
    expect(wordField()).toHaveValue('candid');

    await user.click(addButton());
    await user.click(screen.getByRole('button', { name: 'Add it anyway' }));
    expect(api.createEntry).toHaveBeenCalledTimes(1);
    expect(api.createEntry.mock.calls[0]?.[0]).toMatchObject({ word: 'candid', allowDuplicate: true });
  });

  it('shows the server’s duplicate warning for a word this browser had not loaded', async () => {
    const { api, user } = await open('/add');
    api.createEntry.mockRejectedValueOnce(
      new ApiError('duplicate', '"zeal" is already in your vocabulary.', 409, [entry(77, { word: 'zeal', meaning: 'nhiệt huyết' })]),
    );
    await user.type(await screen.findByLabelText(/^Word/), 'zeal');
    await user.click(addButton());
    expect(await screen.findByRole('alert')).toHaveTextContent('nhiệt huyết');
    expect(screen.queryByText(/was added/)).not.toBeInTheDocument();
    expect(wordField()).toHaveValue('zeal');
  });

  it('keeps the form filled in when saving fails', async () => {
    const { api, user } = await open('/add');
    api.createEntry.mockRejectedValueOnce(new ApiError('forbidden', 'The database refused this change.', 403));
    await user.type(await screen.findByLabelText(/^Word/), 'zeal');
    await user.type(screen.getByLabelText('Definition'), 'great energy');
    await user.click(addButton());

    expect(await screen.findByRole('alert')).toHaveTextContent('The database refused this change.');
    expect(screen.queryByText(/was added/)).not.toBeInTheDocument();
    expect(wordField()).toHaveValue('zeal');
    expect(screen.getByLabelText('Definition')).toHaveValue('great energy');

    // The same submission can simply be sent again.
    await user.click(addButton());
    expect(await screen.findByText(/was added/)).toBeInTheDocument();
    expect(api.createEntry.mock.calls[1]?.[0].requestId).toBe(api.createEntry.mock.calls[0]?.[0].requestId);
  });

  it('sends one request however fast the button is pressed', async () => {
    const { api, user } = await open('/add');
    const pending = deferred<VocabularyEntry>();
    api.createEntry.mockReturnValueOnce(pending.promise);
    await user.type(await screen.findByLabelText(/^Word/), 'zeal');
    const form = screen.getByRole('form', { name: 'Add vocabulary' });
    fireEvent.submit(form);
    fireEvent.submit(form);
    fireEvent.submit(form);
    expect(api.createEntry).toHaveBeenCalledTimes(1);
    await act(async () => pending.resolve(entry(51, { word: 'zeal' })));
  });

  it('uses a fresh request id for each new word', async () => {
    const { api, user } = await open('/add');
    await user.type(await screen.findByLabelText(/^Word/), 'zeal{Enter}');
    await screen.findByText(/was added/);
    await user.type(wordField(), 'verve{Enter}');
    await waitFor(() => expect(api.createEntry).toHaveBeenCalledTimes(2));
    expect(api.createEntry.mock.calls[1]?.[0].requestId).not.toBe(api.createEntry.mock.calls[0]?.[0].requestId);
  });

  it('quick add saves with Enter and sends only the word and meaning', async () => {
    const { api, user } = await open('/add');
    await user.click(await screen.findByLabelText('Quick add'));
    expect(screen.queryByLabelText('Definition')).not.toBeInTheDocument();
    await user.type(wordField(), 'zeal');
    await user.type(screen.getByLabelText('Vietnamese meaning'), 'nhiệt huyết{Enter}');
    expect(api.createEntry).toHaveBeenCalledTimes(1);
    const sent = api.createEntry.mock.calls[0]?.[0];
    expect(sent).toMatchObject({ word: 'zeal', meaning: 'nhiệt huyết', mastery: 1, dateAdded: TODAY });
    expect(sent?.definition).toBeUndefined();
    expect(sent?.example).toBeUndefined();
  });

  it('makes the new word appear in the bank and dashboard without reloading', async () => {
    const { api, user } = await open('/add');
    await user.type(await screen.findByLabelText(/^Word/), 'luminous{Enter}');
    await screen.findByText(/was added/);

    await user.click(within(screen.getAllByRole('navigation', { name: 'Main' })[0]!).getByRole('link', { name: /Vocabulary bank/ }));
    expect(await screen.findByRole('button', { name: 'luminous' })).toBeInTheDocument();
    expect(screen.getByRole('status')).toHaveTextContent('of 4 words');
    expect(api.fetchVocabulary).toHaveBeenCalledTimes(1);
  });

  it('cannot add while saving is switched off', async () => {
    const { api, user } = await open('/add', { list: { writesEnabled: false } });
    expect(await screen.findByText(/Saving is switched off/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Add word' })).toBeDisabled();
    fireEvent.submit(screen.getByRole('form', { name: 'Add vocabulary' }));
    await user.keyboard('{Enter}');
    expect(api.createEntry).not.toHaveBeenCalled();
  });

  it('clears the form on request', async () => {
    const { user } = await open('/add');
    await user.type(await screen.findByLabelText(/^Word/), 'zeal');
    await user.type(screen.getByLabelText('Definition'), 'energy');
    await user.click(screen.getByRole('button', { name: 'Clear form' }));
    expect(wordField()).toHaveValue('');
    expect(screen.getByLabelText('Definition')).toHaveValue('');
    expect(screen.getByLabelText('Date added')).toHaveValue(TODAY);
  });
});

const rows = () => within(screen.getByRole('table')).getAllByRole('row').slice(1);
const rowWords = () => rows().map((row) => within(row).getAllByRole('button')[0]?.textContent);

describe('Vocabulary bank', () => {
  it('lists every word with its stored values', async () => {
    await open('/bank');
    await screen.findByRole('table');
    // Default order: most recently added first.
    expect(rowWords()).toEqual(['alleviate', 'serendipity', 'candid']);
    expect(screen.getByRole('status')).toHaveTextContent('Showing 1–3 of 3 words');
    const candid = rows()[2]!;
    expect(within(candid).getByText('thẳng thắn')).toBeInTheDocument();
    expect(within(candid).getByText('Mastered')).toBeInTheDocument();
    expect(within(candid).getByText(/Missing definition, Missing example/)).toBeInTheDocument();
  });

  it('searches as you type and says when nothing matches', async () => {
    const { user } = await open('/bank');
    const search = await screen.findByRole('searchbox');
    await user.type(search, '  SEREN ');
    expect(rowWords()).toEqual(['serendipity']);
    expect(screen.getByRole('status')).toHaveTextContent('Showing 1–1 of 1 word (filtered from 3)');

    await user.clear(search);
    await user.type(search, 'làm dịu');
    expect(rowWords()).toEqual(['alleviate']);

    await user.clear(search);
    await user.type(search, 'xylophone');
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
    expect(screen.getByText('No words match these filters')).toBeInTheDocument();
    await user.click(screen.getAllByRole('button', { name: 'Clear filters' })[0]!);
    expect(rowWords()).toHaveLength(3);
    expect(search).toHaveValue('');
  });

  it('filters by review status, mastery and preset, and clears them', async () => {
    const { user } = await open('/bank');
    await screen.findByRole('table');
    await user.selectOptions(screen.getByLabelText('Review status'), 'mastered');
    expect(rowWords()).toEqual(['candid']);
    expect(window.location.search).toBe('?status=mastered');

    await user.selectOptions(screen.getByLabelText('Review status'), '');
    await user.selectOptions(screen.getByLabelText('Mastery'), '5');
    expect(rowWords()).toEqual(['alleviate']);

    await user.click(screen.getByRole('button', { name: 'Overdue' }));
    expect(rowWords()).toEqual(['serendipity']);
    expect(screen.getByRole('button', { name: 'Overdue' })).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getByLabelText('Mastery')).toHaveValue('');

    await user.click(screen.getByRole('button', { name: 'Clear filters' }));
    expect(rowWords()).toHaveLength(3);
    expect(screen.getByRole('button', { name: 'All' })).toHaveAttribute('aria-pressed', 'true');
  });

  it('opens with the filters given in the address', async () => {
    await open(`/bank?from=${TODAY}&to=${TODAY}`);
    await screen.findByRole('table');
    expect(rowWords()).toEqual(['alleviate']);
    expect(screen.getByLabelText('Added from')).toHaveValue(TODAY);
  });

  it('sorts by a column and shows which way', async () => {
    const { user } = await open('/bank');
    await screen.findByRole('table');
    const header = (name: string) => screen.getByRole('columnheader', { name: new RegExp(name) });
    expect(header('Date added')).toHaveAttribute('aria-sort', 'descending');

    await user.click(within(header('Word')).getByRole('button'));
    expect(rowWords()).toEqual(['alleviate', 'candid', 'serendipity']);
    expect(header('Word')).toHaveAttribute('aria-sort', 'ascending');
    expect(header('Date added')).toHaveAttribute('aria-sort', 'none');

    await user.click(within(header('Word')).getByRole('button'));
    expect(rowWords()).toEqual(['serendipity', 'candid', 'alleviate']);
    expect(header('Word')).toHaveAttribute('aria-sort', 'descending');

    await user.click(within(header('Mastery')).getByRole('button'));
    expect(rowWords()).toEqual(['candid', 'alleviate', 'serendipity']);
    expect(screen.getByLabelText('Sort by')).toHaveValue('mastery');
  });

  it('pages through a long list', async () => {
    const many = Array.from({ length: 30 }, (_, index) =>
      entry(index + 1, { word: `word-${String(index + 1).padStart(2, '0')}` }),
    );
    const { user } = await open('/bank?sort=word&dir=asc', { entries: many, settings: { bankPageSize: 25 } });
    await screen.findByRole('table');
    expect(rows()).toHaveLength(25);
    expect(screen.getByRole('status')).toHaveTextContent('Showing 1–25 of 30 words');
    expect(screen.getByText('Page 1 of 2')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Previous/ })).toBeDisabled();

    await user.click(screen.getByRole('button', { name: /Next/ }));
    expect(rows()).toHaveLength(5);
    expect(rowWords()[0]).toBe('word-26');
    expect(screen.getByRole('status')).toHaveTextContent('Showing 26–30 of 30 words');
    expect(screen.getByRole('button', { name: /Next/ })).toBeDisabled();

    // Changing a filter starts again from the first page.
    await user.type(screen.getByRole('searchbox'), 'word-0');
    expect(screen.getByRole('status')).toHaveTextContent('Showing 1–9 of 9 words');
  });

  it('offers a compact list view as well', async () => {
    const { user } = await open('/bank');
    await screen.findByRole('table');
    await user.click(screen.getByRole('button', { name: 'Compact list view' }));
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: /serendipity/ })).toBeInTheDocument();
  });

  it('shows an empty state for an empty vocabulary', async () => {
    await open('/bank', { entries: [] });
    expect(await screen.findByText('Your vocabulary is empty')).toBeInTheDocument();
    expect(within(screen.getByRole('main')).getByRole('link', { name: 'Add vocabulary' })).toHaveAttribute('href', '/add');
  });

  it('shows why loading failed and lets the user retry', async () => {
    window.history.replaceState(null, '', '/bank');
    const { api } = createFakeApi({ entries: WORDS });
    api.fetchVocabulary.mockRejectedValueOnce(new ApiError('setup_incomplete', 'No property named "Word".', 503));
    render(<App api={api} settings={createSettingsStore(null)} />);
    expect(await screen.findByRole('alert')).toHaveTextContent('No property named "Word".');
    fireEvent.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByRole('table')).toBeInTheDocument();
  });
});

describe('Word details', () => {
  const openWord = async (options: Options = {}) => {
    const context = await open('/bank', options);
    await context.user.click(await screen.findByRole('button', { name: 'serendipity' }));
    const panel = await screen.findByRole('dialog');
    return { ...context, panel };
  };

  it('opens a panel with everything stored about the word', async () => {
    const { api, panel } = await openWord();
    expect(within(panel).getByRole('heading', { name: 'serendipity' })).toBeInTheDocument();
    expect(within(panel).getByText('sự tình cờ')).toBeInTheDocument();
    expect(within(panel).getByText('definition of word-1')).toBeInTheDocument();
    expect(within(panel).getByText('example for word-1')).toBeInTheDocument();
    expect(within(panel).getByText('Overdue')).toBeInTheDocument();
    expect(within(panel).getByText('Sep 20, 2026')).toBeInTheDocument();
    // Nothing links out of the app: the word lives here. Any link in the panel stays inside it.
    for (const link of within(panel).queryAllByRole('link')) {
      expect(link.getAttribute('href')).toMatch(/^\/(?!\/)/);
    }
    // The latest values are fetched when the panel opens.
    expect(api.fetchEntry).toHaveBeenCalledWith(pageId(1));
    expect(window.location.search).toContain(`word=${pageId(1)}`);
  });

  it('says "Not set" for an empty field instead of inventing a value', async () => {
    const { user } = await open('/bank');
    await user.click(await screen.findByRole('button', { name: 'candid' }));
    const panel = await screen.findByRole('dialog');
    expect(within(panel).getAllByText('Not set')).toHaveLength(2);
    expect(within(panel).getByText(/Missing definition\. Missing example\./)).toBeInTheDocument();
  });

  it('closes with the close button and with Escape', async () => {
    const { user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: 'Close' }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: 'serendipity' }));
    await screen.findByRole('dialog');
    await user.keyboard('{Escape}');
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
  });

  it('saves only the fields that were changed', async () => {
    const { api, user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    const definition = within(panel).getByLabelText('Definition');
    await user.clear(definition);
    await user.type(definition, 'a happy accident');
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));

    expect(api.updateEntry).toHaveBeenCalledExactlyOnceWith(pageId(1), { definition: 'a happy accident' });
    expect(await within(panel).findByText('a happy accident')).toBeInTheDocument();
    expect(within(panel).queryByLabelText('Definition')).not.toBeInTheDocument();
    expect(screen.getByText('Saved “serendipity”.')).toBeInTheDocument();
  });

  it('never sends mastery or the review date unless the schedule section was opened', async () => {
    const { api, user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    await user.type(within(panel).getByLabelText('Example sentences'), ' More.');
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));
    expect(api.updateEntry.mock.calls[0]?.[1]).toEqual({ example: 'example for word-1 More.' });
    expect(api.updateEntry.mock.calls[0]?.[1]).not.toHaveProperty('schedule');
  });

  it('changes the schedule only through its own explicit section', async () => {
    const { api, user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    expect(within(panel).queryByLabelText('Mastery')).not.toBeInTheDocument();
    await user.click(within(panel).getByRole('button', { name: /Review schedule/ }));
    fireEvent.change(within(panel).getByLabelText('Mastery'), { target: { value: '12' } });
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));
    expect(within(panel).getByText('Mastery must be a whole number from 0 to 10.')).toBeInTheDocument();
    expect(api.updateEntry).not.toHaveBeenCalled();

    fireEvent.change(within(panel).getByLabelText('Mastery'), { target: { value: '4' } });
    fireEvent.change(within(panel).getByLabelText('Review date'), { target: { value: '' } });
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));
    expect(api.updateEntry).toHaveBeenCalledExactlyOnceWith(pageId(1), { schedule: { mastery: 4, reviewDate: null } });
  });

  it('keeps what was typed when saving fails', async () => {
    const { api, user, panel } = await openWord();
    api.updateEntry.mockRejectedValueOnce(new ApiError('database_unavailable', 'The database is temporarily unavailable.', 503));
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    const meaning = within(panel).getByLabelText('Vietnamese meaning');
    await user.clear(meaning);
    await user.type(meaning, 'may mắn bất ngờ');
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));

    expect(await within(panel).findByRole('alert')).toHaveTextContent('The database is temporarily unavailable. Your changes are still here.');
    expect(within(panel).getByLabelText('Vietnamese meaning')).toHaveValue('may mắn bất ngờ');
    // Escape must not throw the draft away either.
    await user.keyboard('{Escape}');
    expect(screen.getByRole('dialog')).toBeInTheDocument();

    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));
    expect(await within(panel).findByText('may mắn bất ngờ')).toBeInTheDocument();
  });

  it('validates an edit before sending it', async () => {
    const { api, user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    await user.clear(within(panel).getByLabelText(/^Word/));
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));
    expect(within(panel).getByText('Enter a word.')).toBeInTheDocument();
    expect(api.updateEntry).not.toHaveBeenCalled();
  });

  it('warns when a rename collides with another word', async () => {
    const { api, user, panel } = await openWord();
    api.updateEntry.mockRejectedValueOnce(new ApiError('duplicate', '"candid" is already in your vocabulary.', 409, [WORDS[1]!]));
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    await user.clear(within(panel).getByLabelText(/^Word/));
    await user.type(within(panel).getByLabelText(/^Word/), 'candid');
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));
    expect(await within(panel).findByRole('alert')).toHaveTextContent('Another word is already spelled this way');
    await user.click(within(panel).getByRole('button', { name: 'Save anyway' }));
    expect(api.updateEntry).toHaveBeenLastCalledWith(pageId(1), { word: 'candid', allowDuplicate: true });
  });

  it('shows what the server said when a save arrives after a newer change elsewhere, and writes nothing', async () => {
    const { api, user, panel } = await openWord();
    api.updateEntry.mockRejectedValueOnce(
      new ApiError('conflict', 'The sense list was modified by another request. Please reload and try again.', 409),
    );
    await user.click(within(panel).getByRole('button', { name: /Edit/ }));
    await user.clear(within(panel).getByLabelText(/^Word/));
    await user.type(within(panel).getByLabelText(/^Word/), 'serendipity amended');
    await user.click(within(panel).getByRole('button', { name: 'Save changes' }));

    // A clear message, one attempt, and the form still holds what was typed.
    const alert = await within(panel).findByRole('alert');
    expect(alert).toHaveTextContent('The sense list was modified by another request. Please reload and try again.');
    expect(api.updateEntry).toHaveBeenCalledTimes(1);
    expect(within(panel).getByLabelText(/^Word/)).toHaveValue('serendipity amended');

    // Closing the form leaves the stored word untouched.
    await user.click(within(panel).getByRole('button', { name: 'Cancel' }));
    expect(rowWords()).toContain('serendipity');
    expect(rowWords()).not.toContain('serendipity amended');
  });

  it('asks before deleting, naming the word, and deletes nothing on cancel', async () => {
    const { api, user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: /Delete/ }));
    const confirm = screen.getByRole('heading', { name: 'Delete “serendipity”?' }).closest('dialog')!;
    expect(confirm).toHaveTextContent('will be moved to the trash');
    expect(confirm).toHaveTextContent('mastery of 2');
    await user.click(within(confirm).getByRole('button', { name: 'Cancel' }));
    expect(api.deleteEntry).not.toHaveBeenCalled();
    expect(rowWords()).toContain('serendipity');
  });

  it('moves the word to the trash on confirmation and can undo it', async () => {
    const { api, user, panel } = await openWord();
    await user.click(within(panel).getByRole('button', { name: /Delete/ }));
    await user.click(screen.getByRole('button', { name: 'Move to trash' }));

    await waitFor(() => expect(rowWords()).toEqual(['alleviate', 'candid']));
    expect(api.deleteEntry).toHaveBeenCalledExactlyOnceWith(pageId(1));
    expect(screen.queryByRole('heading', { name: 'serendipity' })).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Undo' }));
    await waitFor(() => expect(rowWords()).toContain('serendipity'));
    expect(api.restoreEntry).toHaveBeenCalledExactlyOnceWith(pageId(1));
  });

  it('keeps the word when deleting fails, and says why', async () => {
    const { api, user, panel } = await openWord();
    api.deleteEntry.mockRejectedValueOnce(new ApiError('forbidden', 'The database refused this change.', 403));
    await user.click(within(panel).getByRole('button', { name: /Delete/ }));
    await user.click(screen.getByRole('button', { name: 'Move to trash' }));
    expect(await screen.findByText('The database refused this change.')).toBeInTheDocument();
    expect(rowWords()).toContain('serendipity');
  });

  it('is read-only while saving is switched off', async () => {
    const { panel } = await openWord({ list: { writesEnabled: false } });
    expect(within(panel).getByRole('button', { name: /Edit/ })).toBeDisabled();
    expect(within(panel).getByRole('button', { name: /Delete/ })).toBeDisabled();
  });
});
