# FC-RC-008 — Verification Record

**Repository state packaged:** branch `newfeature`, HEAD `8d76720ab0cc21771602574a9aa161d5dcbd9e15`
(unchanged across all three tasks; **zero commits, no push/reset/clean/deploy**).
**Environment:** Windows / PowerShell 7; Node **v24.22.0** and npm **11.19.1** located at
`D:\New folder\` (added to `PATH` per command: `$env:PATH += ";D:\New folder"`).
**Test store:** PGlite in-process database running all 13 migrations (single connection).

FC-RC-008 itself required no code changes and no test rerun: no application file was touched
while building this package (git status identical before and after, except the package ZIP,
which is the deliverable).

---

## 1. Automated verification results

The most recent complete gate run (FC-HARDEN-007, final, run after the last code change):

| # | Command | Exit | Result |
|---|---|---|---|
| 1 | `npx vitest run` (G0 baseline, start of FC-HARDEN-007) | 0 | 80 files — **1735 passed, 3 skipped**, 174.5s |
| 2 | `npx vitest run` (FC-HARDEN-007 targeted, 8 suites: import-senses, senses-api, import-export-api, backup-import, shared/import, client import, sense-ui, vocabulary-pages) | 0 | 8 files — **182 passed, 3 skipped** |
| 3 | **`npx vitest run` (FINAL full suite)** | **0** | **81 files — 1759 passed, 3 skipped, 0 failed**, 157s |
| 4 | **`npx tsc --noEmit`** | **0** | 0 errors |
| 5 | **`npx eslint .`** | **0** | clean |
| 6 | **`npm run build`** | **0** | typecheck + `vite build` + `esbuild server/index.ts` (253.3 kB) — one pre-existing cosmetic chunk-size warning only |

Test accounting: baseline **1735 → final 1759 = +24 new tests**
(15 `import-senses` + 6 `senses-api` + 1 import journey + 1 sense-ui journey + 1 vocabulary-pages journey).
The 3 skips are the pre-existing fixture-gated `backup-import` describe (needs a local
`backups/` directory), unchanged before and after. `FC-VERIFY-006-REPORT.md` (included in
this package) records the earlier verification pass; its end state was independently
re-confirmed as gate #1 above.

Suite-level runs recorded during FC-HARDEN-007 (all green in the end):
`senses-api` 21/21 · `import-senses` 15/15 · client `import` + `sense-ui` 36/36 ·
`vocabulary-pages` 38/38.

**Failures found and corrected during the tasks** (evidence of in-scope correction, not
suppression): the import parser initially passed export metadata (`id`/`position`/`version`)
into the strict wire schema → corrected (`keepSenseFields`); several test-side assumptions
corrected (PATCH vs POST on the sense-order endpoint, case-insensitive duplicate matching,
reading trashed rows from the table rather than the live view, restore-to-end position
expectation, isolated store for the second hand-run migration); one `tsc` TS2345 (type-only
cast) fixed. Every failure was task-related; no unrelated code was touched.

**Raw logs still on disk (machine that ran the suite):** `D:\harden_g0_baseline.txt`,
`D:\g1_run1-3.txt`, `D:\g2_run1-2.txt`, `D:\scopeD_run1-2.txt`, `D:\g3_targeted.txt`,
`D:\g3_full.txt`, `D:\journey8b.txt`, `D:\final_vitest.txt`, `D:\final_build.txt`.

## 2. The 16 verification requirements and 8 user journeys

All sixteen §10 requirements were executed as tests (never asserted from code alone) and all
eight UX journeys were verified on the existing jsdom infrastructure — mapping and test names
are listed in `FC-HARDEN-007-REPORT.md` §D (both reports are included in this package).
Highlights: multi-sense round trip (export → restore, senses/order/archive preserved),
duplicate-retry and interrupted-run continuation, overlapping-vocabulary isolation,
cross-account 404s, trashed-word restore and migration backfill of trashed rows,
v12-database refusal of sensed rows.

## 3. Known limitations and outstanding risks

| ID | Status | Item |
|---|---|---|
| R-1 (multi-sense import gap) | **CLOSED** | Fixed and proven in FC-HARDEN-007 (15 round-trip tests) |
| R-2 | **UNVERIFIED** | Genuinely **simultaneous-transaction** behaviour — the local store is PGlite, single connection. Environment was checked: no `psql`/`pg_ctl`/`initdb`, no `docker`/`podman`, no Postgres service, no listener on 127.0.0.1:5432/54321. Sequential collision tests pass; they are **not** presented as proof of overlap safety. Needs a real Postgres/staging run (approval CP-2) |
| R-3 | **BLOCKED** (by contract) | The v13 migration has **not been pushed** to any hosted database (`supabase db push` not run — CP-2/CP-5). Additive-only verified by inspection; upgrade executed only on local PGlite stores |
| R-4 | **BLOCKED** (by contract) | Real-browser E2E not executed (browser framework installation requires CP-3 approval); all 8 journeys verified in jsdom instead |
| R-5 | Informational | Restore-to-end leaves a position gap (positions remain unique; reorder repacks) |
| R-6 | Informational | On a pre-v13 database a sensed import row is refused whole (`invalid` + message) — deliberate, tested |
| R-7 | Low | File import restores **content only** — schedules, history, collections and settings require a database backup (documented project-owner duty; restore drill never performed in this repo) |

Other statements that this package does **not** claim: no production deployment, no
hosted-database verification, no security audit beyond the executed RLS/isolation tests, and
the old-code/new-db compatibility direction was verified by migration inspection
(additive column, view columns preserved, identical RPC parameter lists) rather than by
running a second code version.
